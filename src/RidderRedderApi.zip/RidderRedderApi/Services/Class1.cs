﻿using System;

namespace Services
{
    public class Class1
    {
    }
}
