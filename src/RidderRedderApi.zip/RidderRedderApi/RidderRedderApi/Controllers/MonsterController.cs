﻿using System;
using Microsoft.AspNetCore.Mvc;

namespace RidderRedderApi.Controllers {

    [Route("api/v1/[controller]")]
    public class MonsterController : BaseController {

        //private readonly

        [HttpGet]
        public IActionResult GetMonsters() {
            return Ok("Monster");
        }

    }
}
