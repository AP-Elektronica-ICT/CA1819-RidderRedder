﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace RidderRedderApi.Controllers {

    public class BaseController : Controller {
        public BaseController() {

        }
    }
}
